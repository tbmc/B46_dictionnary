#include <stdio.h>
#include "interface.h"

int main(void)
{
    printf("PROJET DE B46!\n");

    lancer_interface();

    return 0;
}
